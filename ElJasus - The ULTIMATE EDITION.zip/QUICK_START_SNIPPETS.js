// ============================================================
// EL JASUS — QUICK START CODE SNIPPETS
// Copy-paste ready code for common integration tasks
// ============================================================

// ═══════════════════════════════════════════════════════════
// SNIPPET 1: Add Scripts to Page Header
// ═══════════════════════════════════════════════════════════

/* Copy this to the <head> section of ALL pages: */
/*
<script src="name-themes.js"></script>
<script src="friend-invite-enhanced.js" defer></script>
<script src="profile-viewer.js" defer></script>
*/


// ═══════════════════════════════════════════════════════════
// SNIPPET 2: Update Player Name Display in room.html
// ═══════════════════════════════════════════════════════════

/* Replace OLD player name rendering: */
// OLD:
// <p class="font-bold text-sm">${player.username}</p>

/* With NEW themed name rendering: */
function renderPlayerName(uid, playerData, containerElement) {
  const nameContainer = document.createElement('span');
  nameContainer.className = 'player-name-container';
  
  if (window.NameThemes) {
    window.NameThemes.applyPlayerStyle(nameContainer, {
      username: playerData.username || 'Player',
      nameTheme: playerData.nameTheme || 'default',
      nameTag: playerData.nameTag || null,
      rankPoints: playerData.rankPoints || 0
    });
  } else {
    nameContainer.textContent = playerData.username || 'Player';
  }
  
  containerElement.appendChild(nameContainer);
}

// Example usage:
// renderPlayerName(uid, playerData, document.getElementById('player-slot-1'));


// ═══════════════════════════════════════════════════════════
// SNIPPET 3: Load Player Data with Theme/Tag/Rank
// ═══════════════════════════════════════════════════════════

/* When loading player data from Firebase: */
async function loadPlayerWithTheme(uid) {
  const snapshot = await get(ref(db, `players/${uid}`));
  
  if (snapshot.exists()) {
    const data = snapshot.val();
    
    return {
      uid: uid,
      username: data.username || 'Player',
      email: data.email || '',
      
      // Theme system data
      nameTheme: data.nameTheme || 'default',
      nameTag: data.nameTag || null,
      rankPoints: parseInt(data.rankPoints) || 0,
      
      // Inventory
      inventory: data.inventory || {
        nameThemes: ['default'],
        nameTags: []
      },
      
      // Stats
      stats: data.stats || {},
      achievements: data.achievements || {},
      coins: parseInt(data.coins) || 0
    };
  }
  
  return null;
}


// ═══════════════════════════════════════════════════════════
// SNIPPET 4: Add Profile Button to Friend Card
// ═══════════════════════════════════════════════════════════

/* In friends.html, add this button to each friend card: */
function createProfileButton(friendUid, friendUsername) {
  return `
    <button 
      onclick="window.ProfileViewer.open('${friendUid}', '${friendUsername}')" 
      class="px-4 py-2 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 
             text-cyan-400 font-bold text-sm transition-all 
             hover:scale-105 flex items-center gap-2"
      title="عرض الملف الشخصي"
    >
      <i class="fas fa-user"></i>
      <span>الملف الشخصي</span>
    </button>
  `;
}


// ═══════════════════════════════════════════════════════════
// SNIPPET 5: Send Themed Friend Invite
// ═══════════════════════════════════════════════════════════

/* When sending room invite: */
async function sendRoomInvite(friendUid, friendUsername, roomCode) {
  const myData = await loadPlayerWithTheme(currentUser.uid);
  
  try {
    await window.FI.sendInvite(
      friendUid,
      friendUsername,
      roomCode,
      myData.username
    );
    
    // Show success message
    window.FI.showBanner('✅ تم إرسال الدعوة بنجاح!', 'success');
  } catch (error) {
    console.error('Invite error:', error);
    window.FI.showBanner('❌ فشل إرسال الدعوة', 'error');
  }
}


// ═══════════════════════════════════════════════════════════
// SNIPPET 6: Purchase Theme from Shop
// ═══════════════════════════════════════════════════════════

async function purchaseTheme(themeKey, userId) {
  const theme = window.NameThemes.themes[themeKey];
  
  // Get current user data
  const userSnapshot = await get(ref(db, `players/${userId}`));
  const userData = userSnapshot.val();
  
  const currentCoins = parseInt(userData.coins) || 0;
  const currentThemes = userData.inventory?.nameThemes || ['default'];
  
  // Check if already owned
  if (currentThemes.includes(themeKey)) {
    alert('✅ أنت تمتلك هذا الثيم بالفعل!');
    return false;
  }
  
  // Check coins
  if (currentCoins < theme.price) {
    alert('⚠️ ليس لديك عملات كافية!');
    return false;
  }
  
  // Purchase
  try {
    await update(ref(db, `players/${userId}`), {
      coins: currentCoins - theme.price,
      'inventory/nameThemes': [...currentThemes, themeKey]
    });
    
    alert(`✅ تم شراء "${theme.name}" بنجاح!`);
    return true;
  } catch (error) {
    console.error('Purchase error:', error);
    alert('❌ حدث خطأ أثناء الشراء');
    return false;
  }
}


// ═══════════════════════════════════════════════════════════
// SNIPPET 7: Apply Theme to Current User
// ═══════════════════════════════════════════════════════════

async function applyThemeToUser(userId, themeKey) {
  // Check if user owns the theme
  const userSnapshot = await get(ref(db, `players/${userId}`));
  const userData = userSnapshot.val();
  const ownedThemes = userData.inventory?.nameThemes || ['default'];
  
  if (!ownedThemes.includes(themeKey) && themeKey !== 'default') {
    alert('⚠️ يجب شراء هذا الثيم أولاً!');
    return false;
  }
  
  // Apply theme
  try {
    await update(ref(db, `players/${userId}`), {
      nameTheme: themeKey
    });
    
    alert('✅ تم تطبيق الثيم بنجاح!');
    
    // Refresh display
    location.reload();
    return true;
  } catch (error) {
    console.error('Apply theme error:', error);
    alert('❌ حدث خطأ أثناء التطبيق');
    return false;
  }
}


// ═══════════════════════════════════════════════════════════
// SNIPPET 8: Award Coins for Game Win
// ═══════════════════════════════════════════════════════════

async function awardCoinsForWin(userId, wasSpyRole) {
  const coinReward = wasSpyRole ? 50 : 30; // Spy wins get more
  
  const userSnapshot = await get(ref(db, `players/${userId}`));
  const userData = userSnapshot.val();
  const currentCoins = parseInt(userData.coins) || 0;
  
  await update(ref(db, `players/${userId}`), {
    coins: currentCoins + coinReward
  });
  
  return coinReward;
}


// ═══════════════════════════════════════════════════════════
// SNIPPET 9: Update Rank Points
// ═══════════════════════════════════════════════════════════

async function updateRankPoints(userId, pointsToAdd) {
  const userSnapshot = await get(ref(db, `players/${userId}`));
  const userData = userSnapshot.val();
  const currentPoints = parseInt(userData.rankPoints) || 0;
  
  const newPoints = currentPoints + pointsToAdd;
  
  await update(ref(db, `players/${userId}`), {
    rankPoints: newPoints
  });
  
  // Check for rank up
  const oldRank = window.NameThemes.getRank(currentPoints);
  const newRank = window.NameThemes.getRank(newPoints);
  
  if (oldRank.name !== newRank.name) {
    // Rank up notification
    window.FI.showBanner(
      `🎉 تهانينا! ارتقيت إلى رتبة ${newRank.nameAr}!`,
      'success',
      6000
    );
  }
  
  return newPoints;
}


// ═══════════════════════════════════════════════════════════
// SNIPPET 10: Check Achievement Progress
// ═══════════════════════════════════════════════════════════

async function checkAndUnlockAchievement(userId, achievementKey) {
  const userSnapshot = await get(ref(db, `players/${userId}`));
  const userData = userSnapshot.val();
  const achievements = userData.achievements || {};
  
  if (achievements[achievementKey]) {
    return false; // Already unlocked
  }
  
  // Unlock achievement
  await update(ref(db, `players/${userId}/achievements`), {
    [achievementKey]: {
      unlockedAt: Date.now(),
      unlocked: true
    }
  });
  
  // Award coins
  const coinReward = 100;
  const currentCoins = parseInt(userData.coins) || 0;
  await update(ref(db, `players/${userId}`), {
    coins: currentCoins + coinReward
  });
  
  // Show notification
  window.FI.showBanner(
    `🏆 إنجاز جديد! حصلت على +${coinReward} عملة`,
    'success',
    5000
  );
  
  return true;
}


// ═══════════════════════════════════════════════════════════
// SNIPPET 11: Complete Firebase Structure Example
// ═══════════════════════════════════════════════════════════

/* Your Firebase structure should look like this: */

const exampleFirebaseStructure = {
  players: {
    "user_uid_123": {
      username: "Ahmed",
      email: "ahmed@example.com",
      coins: 500,
      rankPoints: 2750,
      
      // Theme system
      nameTheme: "fireGold",
      nameTag: "legend",
      
      // Inventory
      inventory: {
        nameThemes: ["default", "neonCyan", "fireGold", "pulseGlow"],
        nameTags: ["vip", "legend", "pro"]
      },
      
      // Stats
      stats: {
        totalGames: 45,
        spyWins: 12,
        innocentWins: 20,
        spyGames: 15,
        currentStreak: 3,
        longestWinStreak: 7,
        spyDetectionRate: 68,
        timesCaughtAsSpy: 3,
        averageDiscussionTime: 180
      },
      
      // Achievements
      achievements: {
        firstWin: { unlocked: true, unlockedAt: 1234567890 },
        masterDeceiver: { unlocked: true, unlockedAt: 1234567891 },
        hotStreak: { unlocked: false }
      }
    }
  },
  
  invites: {
    "user_uid_456": {
      "invite_id_xyz": {
        fromUid: "user_uid_123",
        fromName: "Ahmed",
        roomCode: "ABC123",
        timestamp: 1234567890,
        expiresAt: 1234567890 + 300000, // 5 mins
        status: "pending" // or "accepted" or "declined" or "expired"
      }
    }
  },
  
  rooms: {
    "ABC123": {
      host: "Ahmed",
      status: "waiting", // or "playing", "discussion", "voting", "reveal"
      players: ["Ahmed", "Player2", "Player3"],
      // ... other room data
    }
  }
};


// ═══════════════════════════════════════════════════════════
// SNIPPET 12: Initialize Theme System on Page Load
// ═══════════════════════════════════════════════════════════

/* Add this to your main initialization: */
document.addEventListener('DOMContentLoaded', async () => {
  // Wait for Firebase auth
  onAuthStateChanged(auth, async (user) => {
    if (user) {
      // Load user data with theme
      const userData = await loadPlayerWithTheme(user.uid);
      
      // Apply themes to any existing player names on page
      document.querySelectorAll('[data-player-uid]').forEach(el => {
        const uid = el.dataset.playerUid;
        if (window.gameState?.players[uid]) {
          window.NameThemes.applyPlayerStyle(el, window.gameState.players[uid]);
        }
      });
    }
  });
});


// ═══════════════════════════════════════════════════════════
// SNIPPET 13: Create Theme Preview in Shop
// ═══════════════════════════════════════════════════════════

function createThemePreview(themeKey) {
  const container = document.createElement('div');
  container.className = 'theme-preview-container';
  container.style.cssText = `
    padding: 20px;
    background: rgba(0,0,0,0.3);
    border-radius: 12px;
    text-align: center;
    margin: 10px 0;
  `;
  
  const previewText = document.createElement('span');
  previewText.className = 'theme-preview-text';
  previewText.id = `preview-${themeKey}`;
  
  container.appendChild(previewText);
  
  // Apply theme after render
  setTimeout(() => {
    if (window.NameThemes) {
      window.NameThemes.applyTheme(previewText, themeKey, 'اسم اللاعب');
    }
  }, 100);
  
  return container;
}


// ═══════════════════════════════════════════════════════════
// SNIPPET 14: Search for Player by Username
// ═══════════════════════════════════════════════════════════

async function searchPlayerByUsername(searchQuery) {
  const playersSnapshot = await get(ref(db, 'players'));
  
  if (!playersSnapshot.exists()) {
    return [];
  }
  
  const allPlayers = playersSnapshot.val();
  const results = [];
  
  Object.entries(allPlayers).forEach(([uid, data]) => {
    const username = (data.username || '').toLowerCase();
    const query = searchQuery.toLowerCase();
    
    if (username.includes(query)) {
      results.push({
        uid: uid,
        username: data.username,
        nameTheme: data.nameTheme || 'default',
        nameTag: data.nameTag || null,
        rankPoints: data.rankPoints || 0
      });
    }
  });
  
  return results;
}


// ═══════════════════════════════════════════════════════════
// SNIPPET 15: Add Profile Button to Search Results
// ═══════════════════════════════════════════════════════════

function renderSearchResults(results, containerElement) {
  containerElement.innerHTML = '';
  
  results.forEach(player => {
    const card = document.createElement('div');
    card.className = 'glass rounded-xl p-4 mb-3';
    
    const nameContainer = document.createElement('div');
    nameContainer.className = 'flex items-center justify-between';
    
    // Left side: themed name
    const nameDisplay = document.createElement('div');
    if (window.NameThemes) {
      window.NameThemes.applyPlayerStyle(nameDisplay, player);
    } else {
      nameDisplay.textContent = player.username;
    }
    
    // Right side: profile button
    const profileBtn = document.createElement('button');
    profileBtn.className = 'px-4 py-2 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 font-bold text-sm transition-all';
    profileBtn.innerHTML = '<i class="fas fa-user"></i> عرض';
    profileBtn.onclick = () => window.ProfileViewer.open(player.uid, player.username);
    
    nameContainer.appendChild(nameDisplay);
    nameContainer.appendChild(profileBtn);
    card.appendChild(nameContainer);
    containerElement.appendChild(card);
  });
}


// ═══════════════════════════════════════════════════════════
// USAGE EXAMPLES
// ═══════════════════════════════════════════════════════════

/*
// Example 1: Complete room.html integration
async function initializeRoom() {
  const roomCode = localStorage.getItem('currentRoom');
  const roomData = await loadRoomData(roomCode);
  
  // Render each player with themes
  roomData.players.forEach(async (playerName) => {
    const playerData = await findPlayerByUsername(playerName);
    if (playerData) {
      const slot = document.getElementById(`player-slot-${playerName}`);
      renderPlayerName(playerData.uid, playerData, slot);
    }
  });
}

// Example 2: Complete friends.html integration
async function loadFriendsList() {
  const friends = await getFriends(currentUser.uid);
  const container = document.getElementById('friends-list');
  
  friends.forEach(friend => {
    const friendCard = createFriendCard(friend);
    container.appendChild(friendCard);
  });
}

function createFriendCard(friendData) {
  const card = document.createElement('div');
  card.className = 'glass rounded-2xl p-5 mb-3';
  
  // Name with theme
  const nameDisplay = document.createElement('div');
  window.NameThemes.applyPlayerStyle(nameDisplay, friendData);
  
  // Profile button
  const profileBtn = document.createElement('button');
  profileBtn.onclick = () => window.ProfileViewer.open(friendData.uid, friendData.username);
  profileBtn.textContent = 'عرض الملف';
  
  card.appendChild(nameDisplay);
  card.appendChild(profileBtn);
  return card;
}
*/


// ═══════════════════════════════════════════════════════════
// TROUBLESHOOTING
// ═══════════════════════════════════════════════════════════

/* 
Common Issues:

1. "window.NameThemes is undefined"
   → Make sure name-themes.js is loaded
   → Check browser console for errors
   → Add: <script src="name-themes.js"></script>

2. "Themes not showing"
   → Verify player data has nameTheme field
   → Check CSS injection: document.getElementById('ej-name-themes-styles')
   → Wait for DOM ready before applying themes

3. "Invites not appearing"
   → Check Firebase rules: /invites/{uid} must be readable
   → Verify friend-invite-enhanced.js is loaded
   → Check console for Firebase errors

4. "Profile modal won't open"
   → Ensure profile-viewer.js is loaded
   → Check if player data exists in Firebase
   → Verify UID is correct

5. "Still seeing NaN errors"
   → Use the fixed HTML files (account-fixed.html, profile-fixed.html)
   → Clear browser cache
   → Check parseInt() is used on all numeric values

For more help, see INTEGRATION_GUIDE.md
*/
